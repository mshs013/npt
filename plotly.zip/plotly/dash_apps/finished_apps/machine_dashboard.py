# frontend/dash_apps/apps/machine_dashboard.py
from dash import html, dcc
import dash_bootstrap_components as dbc
from dash import dash_table
from django_plotly_dash import DjangoDash
import pandas as pd
import plotly.express as px
from library.models import ProcessedNPT, RotationStatus, Shift

app = DjangoDash("MachineDashboard", serve_locally=True)


# ---------------------
# Adminlte widget
# ---------------------
def info_box(value, label, color="bg-info", icon="fas fa-cog", unit=""):
    return html.Div(
        className="info-box",
        children=[
            # Icon
            html.Span(
                className=f"info-box-icon {color} elevation-1",
                children=[html.I(className=icon)]
            ),
            # Content
            html.Div(
                className="info-box-content",
                children=[
                    html.Span(className="info-box-text", children=label),
                    html.Span(
                        className="info-box-number",
                        children=[value, html.Small(unit)] if unit else value
                    )
                ]
            )
        ]
    )

# ---------------------
# Fetch Data
# ---------------------
npt_qs = ProcessedNPT.objects.all()
rot_qs = RotationStatus.objects.all()
shifts = Shift.objects.all()

# Convert NPT queryset to DataFrame
npt_df = pd.DataFrame(list(npt_qs.values("mc_no", "reason__name", "off_time", "on_time")))

# Convert Rotation queryset to DataFrame
rot_df = pd.DataFrame(list(rot_qs.values("mc_no", "count", "count_time")))

# ---------------------
# Determine Shift for each record
# ---------------------
def get_shift(dt):
    for s in shifts:
        start = pd.Timestamp(dt.date().strftime('%Y-%m-%d') + ' ' + s.start_time.strftime('%H:%M:%S'))
        end = pd.Timestamp(dt.date().strftime('%Y-%m-%d') + ' ' + s.end_time.strftime('%H:%M:%S'))
        if end < start:  # handle overnight shifts
            end += pd.Timedelta(days=1)
        if start <= dt <= end:
            return s.name
    return "Unknown"

npt_df['shift_name'] = npt_df['off_time'].apply(get_shift)

# ---------------------
# Compute NPT duration in hours
# ---------------------
npt_df['npt_hours'] = npt_df.apply(
    lambda row: (row['on_time'] - row['off_time']).total_seconds()/3600 
    if row['on_time'] else (pd.Timestamp.now() - row['off_time']).total_seconds()/3600,
    axis=1
)

# ---------------------
# Metrics for Cards
# ---------------------
total_npt = npt_df['npt_hours'].sum()
total_events = len(npt_df)
machine_count = npt_df['mc_no'].nunique()
overall_npt_percent = round(total_npt / (total_npt + 10) * 100, 2)  # example
overall_pt_percent = 100 - overall_npt_percent
rolls_produced_total = 55  # example

# ---------------------
# Figures (Charts)
# ---------------------
fig_npt_by_machine = px.bar(
    npt_df.groupby('mc_no', as_index=False)['npt_hours'].sum(),
    x='mc_no', y='npt_hours', title="NPT by Machine"
)

fig_npt_by_reason = px.pie(
    npt_df, names='reason__name', values='npt_hours', title="NPT by Reasons"
)

fig_hourly_trend = px.line(
    rot_df, x='count_time', y='count', color='mc_no', title="Hourly NPT Trend (Last 24h)"
)

fig_npt_by_shift = px.bar(
    npt_df.groupby(['mc_no', 'shift_name'], as_index=False)['npt_hours'].sum(),
    x='mc_no', y='npt_hours', color='shift_name',
    title="Machine NPT by Shift",
    barmode='stack'
)

fig_shiftwise_npt = px.pie(
    npt_df.groupby('shift_name', as_index=False)['npt_hours'].sum(),
    names='shift_name', values='npt_hours',
    title="Shiftwise NPT Distribution"
)

fig_machine_perf = px.bar(
    npt_df.groupby('mc_no', as_index=False)['npt_hours'].mean(),
    x='mc_no', y='npt_hours',
    title="Average NPT per Machine"
)

fig_shiftwise_trend = px.line(
    npt_df.groupby(['shift_name', 'off_time'], as_index=False)['npt_hours'].sum(),
    x='off_time', y='npt_hours', color='shift_name',
    title="Shiftwise NPT Overview"
)

# ---------------------
# Machine Performance Summary Table
# ---------------------
machine_summary = npt_df.groupby('mc_no').agg(
    total_npt=('npt_hours', 'sum'),
    events=('mc_no', 'count')
).reset_index()

# Add calculated columns
machine_summary['avg_npt_per_event'] = machine_summary['total_npt'] / machine_summary['events']
machine_summary['rolls_produced'] = rolls_produced_total  # example static value
machine_summary['efficiency'] = (1 - machine_summary['total_npt']/10) * 100  # example formula
machine_summary['status'] = machine_summary['efficiency'].apply(lambda x: "Good" if x > 70 else "Warning")
machine_summary['performance'] = machine_summary['efficiency']  # can be same as efficiency or custom

machine_summary_table = dash_table.DataTable(
    columns=[{"name": i.replace('_',' ').title(), "id": i} for i in machine_summary.columns],
    data=machine_summary.to_dict('records'),
    style_table={'overflowX': 'auto'},
    style_cell={'textAlign': 'center', 'padding': '5px'},
    style_header={'backgroundColor': '#f8f9fa', 'fontWeight': 'bold'}
)

# ---------------------
# Shiftwise NPT Overview Table
# ---------------------
shift_summary = npt_df.groupby('shift_name').agg(
    total_npt=('npt_hours', 'sum'),
    events=('shift_name', 'count')
).reset_index()

shift_summary['avg_npt_per_event'] = shift_summary['total_npt'] / shift_summary['events']
shift_summary['performance'] = (1 - shift_summary['total_npt']/10) * 100  # example formula

shift_summary_table = dash_table.DataTable(
    columns=[{"name": i.replace('_',' ').title(), "id": i} for i in shift_summary.columns],
    data=shift_summary.to_dict('records'),
    style_table={'overflowX': 'auto'},
    style_cell={'textAlign': 'center', 'padding': '5px'},
    style_header={'backgroundColor': '#f8f9fa', 'fontWeight': 'bold'}
)


# ---------------------
# Layout
# ---------------------
app.layout = dbc.Container([
    # Cards Row
    dbc.Row([
        dbc.Col(info_box(f"{int(total_npt)}h {int(total_npt % 1*60)}m", "Total NPT", "bg-info", "fas fa-clock", '%'), width=2),
        dbc.Col(dbc.Card(dbc.CardBody([html.H5("Total Events"), html.H2(total_events)])), width=2),
        dbc.Col(dbc.Card(dbc.CardBody([html.H5("Machines"), html.H2(machine_count)])), width=2),
        dbc.Col(dbc.Card(dbc.CardBody([html.H5("Overall NPT %"), html.H2(f"{overall_npt_percent}%")])), width=2),
        dbc.Col(dbc.Card(dbc.CardBody([html.H5("Overall PT %"), html.H2(f"{overall_pt_percent}%")])), width=2),
        dbc.Col(dbc.Card(dbc.CardBody([html.H5("Rolls Produced"), html.H2(rolls_produced_total)])), width=2),
    ], className="mb-4"),

    # Original Charts
    dbc.Row([
        dbc.Col(dcc.Graph(figure=fig_npt_by_machine, style={"height":"400px"}), width=6),
        dbc.Col(dcc.Graph(figure=fig_npt_by_reason, style={"height":"400px"}), width=6)
    ], className="mb-4"),
    dbc.Row([
        dbc.Col(dcc.Graph(figure=fig_hourly_trend, style={"height":"400px"}), width=12)
    ], className="mb-4"),

    # Shift-based Charts
    dbc.Row([
        dbc.Col(dcc.Graph(figure=fig_npt_by_shift, style={"height":"400px"}), width=6),
        dbc.Col(dcc.Graph(figure=fig_shiftwise_npt, style={"height":"400px"}), width=6)
    ], className="mb-4"),
    dbc.Row([
        dbc.Col(dcc.Graph(figure=fig_machine_perf, style={"height":"400px"}), width=6),
        dbc.Col(dcc.Graph(figure=fig_shiftwise_trend, style={"height":"400px"}), width=6)
    ], className="mb-4"),

    # Tables
    dbc.Row([
        dbc.Col([
            html.H5("Machine Performance Summary"),
            machine_summary_table
        ], width=6),
        dbc.Col([
            html.H5("Shiftwise NPT Overview"),
            shift_summary_table
        ], width=6)
    ], className="mb-4"),

], fluid=True)
